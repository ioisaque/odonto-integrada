=== Motive Events ===
Contributors: iworks
Description: Motive Events plugin
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allow to manage events

== Description ==

== Installation ==

1. Upload Motive Events to your plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure Motive Events plugin using Events -> Settings

== Changelog ==

= 1.4.2

* Release date: 2016-02-04
* Fixed the issue with empty timestamp if hour field is disabled.
* Fixed a problem with menu.
* Fixed wrong taxonomy select in archive taxonomy selector.

= 1.4.1

* Release date: 2015-09-11
* BUGFIX: fixed a problem with next link.

= 1.4

* Release date: 2014-11-25
* IMPROVEMENT: added date to title, format depend on chosen period.
* IMPROVEMENT: added pagination on event taxonomy page
* BUGFIX: fixed a problem with events having hour

= 1.3.5

* BUGFIX: I fixed a problem with links.
* IMPROVEMENT: added widget calendar with upcoming eveents

= 1.3.4

* IMPROVEMENT: when links are hash, then display only existing categories.
* IMPROVEMENT: added filter "iworks_events_thumbnails" - use this filter to change post thumbnail images.

