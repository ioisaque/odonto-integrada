<?php

function iworks_events_options()
{
    $iworks_events_options = array();

    /**
     * main settings
     */
    $iworks_events_options['index'] = array(
        'use_tabs' => true,
        'version' => '0.0',
        'options' => array(
            array(
                'name' => 'last_used_tab',
                'type' => 'hidden',
                'dynamic' => true,
                'autoload' => false,
                'default' => 0
            ),
            array(
                'type' => 'heading',
                'label' => __('Upcoming events', 'iworks_events'),
            ),
            array(
                'name' => 'upcoming_show',
                'type' => 'checkbox',
                'th' => __('Show Upcoming Events', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'yes',
            ),
            array(
                'name' => 'upcoming_number',
                'type' => 'number',
                'min' => 1,
                'th' => __('Numer of events', 'iworks_events' ),
                'sanitize' => 'intval',
                'default' => 3,
                'class' => 'small-text',
                'dashicon' => 'screenoptions',
            ),
            array(
                'type' => 'heading',
                'label' => __('Other', 'iworks_events'),
            ),
            array(
                'name' => 'archive',
                'type' => 'serialize',
                'th' => __( 'Category for past events', 'events' ),
                'callback' => 'iworks_archive_event_category',
                'description' => __( 'There is no need to assign to this category.', 'iworks_events' ),
                'dashicon' => 'category',
            ),
            array(
                'name' => 'show_alerts',
                'type' => 'checkbox',
                'th' => __('Show alerts', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'flag',
            ),
            array(
                'name' => 'list_type',
                'type' => 'radio',
                'th' => __('Taxonomy event list type', 'iworks_events' ),
                'default' => 'hash',
                'radio' => array(
                    'hash' => array(
                        'label' => __('anchor', 'iworks_events' ),
                        'description' => __('Create list of anchors with taxonomy slug.', 'iworks_events' ),
                    ),
                    'link' => array(
                        'label' => __('link', 'iworks_events' ),
                        'description' => __('Create list of links to taxonomy.', 'iworks_events' ),
                    ),
                ),
                'dashicon' => 'admin-links',
            ),
            array(
                'name' => 'all_name',
                'type' => 'text',
                'th' => __('Name for all events', 'iworks_events' ),
                'description' => __('Enter name of link to show all evens.', 'iworks_events' ),
                'sanitize' => 'esc_html',
                'default' => __('All', 'iworks_events'),
                'dashicon' => 'welcome-write-blog',
            ),
            array(
                'name' => 'events_page_limit',
                'type' => 'number',
                'min' => 1,
                'th' => __('Numer of events on events page', 'iworks_events' ),
                'sanitize' => 'intval',
                'default' => 3,
                'class' => 'small-text',
                'dashicon' => 'screenoptions',
            ),
            array(
                'type' => 'heading',
                'label' => __('Widgets', 'iworks_events'),
            ),
            array(
                'name' => 'widget_calendar',
                'type' => 'checkbox',
                'th' => __('Calendar', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'calendar',
            ),
            array(
                'type' => 'heading',
                'label' => __('Fields', 'iworks_events'),
            ),
            array(
                'name' => 'field_editor',
                'type' => 'checkbox',
                'th' => __('Content', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'media-document',
            ),
            array(
                'name' => 'field_excerpt',
                'type' => 'checkbox',
                'th' => __('Excerpt', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'menu',
            ),
            array(
                'name' => 'field_thumbnail',
                'type' => 'checkbox',
                'th' => __('Feature image', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'format-image',
            ),
            array(
                'name' => 'field_hour',
                'type' => 'checkbox',
                'th' => __('Hour', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'clock',
            ),
            array(
                'name' => 'field_end',
                'type' => 'checkbox',
                'th' => __('Date end', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => false,
                'dashicon' => 'calendar-alt',
            ),
            array(
                'name' => 'field_place',
                'type' => 'checkbox',
                'th' => __('Place', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'location',
            ),
            array(
                'name' => 'field_city',
                'type' => 'checkbox',
                'th' => __('City', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'admin-site',
            ),
            array(
                'name' => 'field_address',
                'type' => 'checkbox',
                'th' => __('Address', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => true,
                'dashicon' => 'location-alt',
            ),
            array(
                'name' => 'field_url',
                'type' => 'checkbox',
                'th' => __('Url', 'iworks_events'),
                'sanitize' => 'intval',
                'default' => false,
                'dashicon' => 'admin-links',
            ),
        ),
    );

    return $iworks_events_options;
}

function iworks_archive_event_category($option_value, $option_name)
{
    global $iworks_events;
    return $iworks_events->select_archive_category( $option_name, __('None') );
}

